"""henzai - AI-First GNOME Desktop Assistant

Main entry point for the henzai daemon service.
"""

import sys
import logging
from gi.repository import GLib
from .dbus_service import henzaiService
from .llm import LLMClient
from .memory import MemoryStore

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/tmp/henzai-daemon.log')
    ]
)

logger = logging.getLogger(__name__)


def _wait_for_ramalama(llm_client, timeout=60, poll_interval=0.5):
    """
    Wait for Ramalama API to be ready before proceeding.
    
    This prevents the daemon from accepting requests when Ramalama is still
    loading the model into memory (which can take 15-20 seconds for large models).
    
    Args:
        llm_client: LLMClient instance to check
        timeout: Maximum time to wait in seconds
        poll_interval: Time between checks in seconds
    """
    import time
    import requests
    
    start_time = time.time()
    last_log_time = start_time
    
    while time.time() - start_time < timeout:
        try:
            # Try to connect to Ramalama API
            response = requests.get(
                f"{llm_client.api_url}/v1/models",
                timeout=2
            )
            if response.status_code == 200:
                elapsed = time.time() - start_time
                logger.info(f"✅ Ramalama is ready! (waited {elapsed:.1f}s)")
                return True
        except requests.exceptions.ConnectionError:
            # Ramalama not ready yet
            pass
        except Exception as e:
            logger.debug(f"Ramalama check failed: {e}")
        
        # Log progress every 5 seconds
        if time.time() - last_log_time >= 5:
            elapsed = time.time() - start_time
            logger.info(f"Still waiting for Ramalama... ({elapsed:.0f}s elapsed)")
            last_log_time = time.time()
        
        time.sleep(poll_interval)
    
    # Timeout reached
    logger.warning(f"Ramalama not ready after {timeout}s, starting anyway")
    logger.warning("Users may see connection errors until Ramalama finishes loading")
    return False


def main():
    """Main entry point for the henzai daemon."""
    logger.info("Starting henzai daemon...")
    
    try:
        # Initialize memory store
        logger.info("Initializing memory store...")
        memory = MemoryStore()
        
        # Initialize LLM client (will auto-detect model from Ramalama)
        logger.info("Initializing LLM client...")
        llm = LLMClient()
        
        # Try to detect current model from Ramalama systemd service file
        try:
            import subprocess
            result = subprocess.run(
                ['systemctl', '--user', 'cat', 'ramalama.service'],
                capture_output=True,
                text=True,
                timeout=2
            )
            if result.returncode == 0:
                # Parse ExecStart line to get the actual model being served
                for line in result.stdout.split('\n'):
                    if 'ExecStart=' in line and 'ramalama serve' in line:
                        # Extract model from ExecStart line (last argument)
                        parts = line.split()
                        if len(parts) > 0:
                            model_arg = parts[-1]  # Last argument is usually the model
                            if 'ollama://' in model_arg or 'library/' in model_arg or ':' in model_arg:
                                detected_model = model_arg
                                llm.model = detected_model
                                logger.info(f"Detected model from ramalama.service: {detected_model}")
                                break
            else:
                logger.warning(f"Could not read ramalama.service, using default: {llm.model}")
        except Exception as e:
            logger.warning(f"Could not detect model from ramalama.service: {e}, using default: {llm.model}")
        
        # Wait for Ramalama to be ready before starting D-Bus service
        logger.info("Waiting for Ramalama to be ready...")
        _wait_for_ramalama(llm)
        
        # Auto-detect reasoning support and enable if available
        if llm.supports_reasoning():
            llm.reasoning_enabled = True
            logger.info(f"Reasoning mode auto-enabled for model: {llm.model}")
        else:
            llm.reasoning_enabled = False
            logger.info(f"Reasoning mode not available for model: {llm.model}")
        
        # Create and register D-Bus service
        logger.info("Creating D-Bus service...")
        service = henzaiService(llm, memory)
        
        logger.info("henzai daemon started successfully")
        logger.info("D-Bus service available at: org.gnome.henzai")
        
        # Run the main loop
        loop = GLib.MainLoop()
        loop.run()
        
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt, shutting down...")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()










