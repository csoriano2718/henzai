"""henzai package initialization."""

__version__ = "0.1.0"
__author__ = "Christian Soriano"
__description__ = "AI-First GNOME Desktop Assistant"










