"""Tests for henzai daemon."""

